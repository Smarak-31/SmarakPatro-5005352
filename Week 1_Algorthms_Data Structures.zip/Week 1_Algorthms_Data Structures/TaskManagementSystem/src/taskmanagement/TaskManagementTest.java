package taskmanagement;

public class TaskManagementTest {
    public static void main(String[] args) {
        TaskManagementSystem system = new TaskManagementSystem();

        Task task1 = new Task(1, "Task 1", "Pending");
        Task task2 = new Task(2, "Task 2", "In Progress");
        Task task3 = new Task(3, "Task 3", "Completed");

        system.addTask(task1);
        system.addTask(task2);
        system.addTask(task3);

        System.out.println("Traverse Tasks:");
        system.traverseTasks();

        System.out.println("\nSearch for Task with ID 2:");
        Task searchedTask = system.searchTask(2);
        System.out.println(searchedTask != null ? searchedTask : "Task not found");

        System.out.println("\nDelete Task with ID 2:");
        system.deleteTask(2);
        system.traverseTasks();
    }
}
