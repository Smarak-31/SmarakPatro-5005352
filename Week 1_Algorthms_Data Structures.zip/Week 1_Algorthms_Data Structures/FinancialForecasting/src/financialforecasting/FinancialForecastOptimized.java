package financialforecasting;

import java.util.HashMap;
import java.util.Map;

public class FinancialForecastOptimized {
    
    private static Map<Integer, Double> memo = new HashMap<>();
    
    // Method to calculate future value using a recursive approach with memoization
    public static double calculateFutureValue(double presentValue, double growthRate, int years) {
        // Base case: if no more years to calculate, return the present value
        if (years == 0) {
            return presentValue;
        }
        // Check if the value for this year has already been computed
        if (memo.containsKey(years)) {
            return memo.get(years);
        }
        // Recursive case: calculate the value for the next year and store it in the memo map
        double futureValue = calculateFutureValue(presentValue * (1 + growthRate), growthRate, years - 1);
        memo.put(years, futureValue);
        return futureValue;
    }
    
    public static void main(String[] args) {
        double presentValue = 1000.0; // Initial amount
        double annualGrowthRate = 0.05; // Annual growth rate of 5%
        int years = 10; // Number of years

        double futureValue = calculateFutureValue(presentValue, annualGrowthRate, years);
        System.out.println("Future value after " + years + " years: $" + futureValue);
    }
}
