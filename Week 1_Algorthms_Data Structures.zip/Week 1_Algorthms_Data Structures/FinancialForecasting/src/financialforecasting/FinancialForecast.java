package financialforecasting;

public class FinancialForecast {
    
    // Method to calculate future value using a recursive approach
    public static double calculateFutureValue(double presentValue, double growthRate, int years) {
        // Base case: if no more years to calculate, return the present value
        if (years == 0) {
            return presentValue;
        }
        // Recursive case: calculate the value for the next year
        return calculateFutureValue(presentValue * (1 + growthRate), growthRate, years - 1);
    }
    
    public static void main(String[] args) {
        double presentValue = 1000.0; // Initial amount
        double annualGrowthRate = 0.05; // Annual growth rate of 5%
        int years = 10; // Number of years

        double futureValue = calculateFutureValue(presentValue, annualGrowthRate, years);
        System.out.println("Future value after " + years + " years: $" + futureValue);
    }
}
