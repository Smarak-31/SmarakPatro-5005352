package inventorymanagementsystem;

public class InventoryManagementSystem {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();

        // Adding products
        Product p1 = new Product("1", "Product1", 100, 50.0);
        Product p2 = new Product("2", "Product2", 200, 30.0);
        manager.addProduct(p1);
        manager.addProduct(p2);

        // Displaying inventory
        System.out.println("Initial Inventory:");
        manager.displayInventory();

        // Updating a product
        Product p1Updated = new Product("1", "Product1 Updated", 150, 55.0);
        manager.updateProduct(p1Updated);
        
        // Displaying inventory after update
        System.out.println("Inventory After Update:");
        manager.displayInventory();

        // Deleting a product
        manager.deleteProduct("2");

        // Displaying inventory after deletion
        System.out.println("Inventory After Deletion:");
        manager.displayInventory();
    }
}
