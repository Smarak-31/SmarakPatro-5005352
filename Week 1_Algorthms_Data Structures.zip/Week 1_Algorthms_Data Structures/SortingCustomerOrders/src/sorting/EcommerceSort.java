package sorting;

import java.util.Arrays;

public class EcommerceSort {

    public static void main(String[] args) {
        // Sample orders
        Order[] orders = {
            new Order("1", "Alice", 250.50),
            new Order("2", "Bob", 150.75),
            new Order("3", "Charlie", 300.40),
            new Order("4", "David", 200.20),
            new Order("5", "Eve", 100.10)
        };

        // Bubble Sort
        Order[] bubbleSortedOrders = Arrays.copyOf(orders, orders.length);
        SortAlgorithms.bubbleSort(bubbleSortedOrders);
        System.out.println("Bubble Sorted Orders:");
        for (Order order : bubbleSortedOrders) {
            System.out.println(order);
        }

        // Quick Sort
        Order[] quickSortedOrders = Arrays.copyOf(orders, orders.length);
        SortAlgorithms.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        System.out.println("\nQuick Sorted Orders:");
        for (Order order : quickSortedOrders) {
            System.out.println(order);
        }
    }
}
