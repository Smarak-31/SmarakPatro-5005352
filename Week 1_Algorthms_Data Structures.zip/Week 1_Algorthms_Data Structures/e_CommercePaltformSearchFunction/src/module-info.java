module e_CommercePaltformSearchFunction {
}