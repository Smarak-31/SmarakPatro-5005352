package ecommerce;

public class EcommerceSearch {

    public static void main(String[] args) {
        // Sample products
        Product[] products = {
            new Product("1", "Laptop", "Electronics"),
            new Product("2", "Smartphone", "Electronics"),
            new Product("3", "Tablet", "Electronics"),
            new Product("4", "Headphones", "Accessories"),
            new Product("5", "Charger", "Accessories")
        };

        // Linear Search
        String searchId = "3";
        Product result = SearchAlgorithms.linearSearch(products, searchId);
        System.out.println("Linear Search Result: " + (result != null ? result : "Product not found"));

        // Binary Search
        result = SearchAlgorithms.binarySearch(products, searchId);
        System.out.println("Binary Search Result: " + (result != null ? result : "Product not found"));
    }
}
