package employeemanagement;

public class EmployeeManagementTest {
    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem(2);

        Employee emp1 = new Employee(1, "John Doe", "Manager", 75000);
        Employee emp2 = new Employee(2, "Jane Smith", "Developer", 65000);
        Employee emp3 = new Employee(3, "Emily Davis", "Designer", 60000);

        system.addEmployee(emp1);
        system.addEmployee(emp2);
        system.addEmployee(emp3);

        System.out.println("Traverse Employees:");
        system.traverseEmployees();

        System.out.println("\nSearch for Employee with ID 2:");
        Employee searchedEmployee = system.searchEmployee(2);
        System.out.println(searchedEmployee != null ? searchedEmployee : "Employee not found");

        System.out.println("\nDelete Employee with ID 2:");
        system.deleteEmployee(2);
        system.traverseEmployees();
    }
}
