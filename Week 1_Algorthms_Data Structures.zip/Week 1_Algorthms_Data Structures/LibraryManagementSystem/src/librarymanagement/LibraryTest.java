package librarymanagement;

import java.util.ArrayList;
import java.util.List;

public class LibraryTest {
    public static void main(String[] args) {
        List<Book> books = new ArrayList<>();
        books.add(new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"));
        books.add(new Book(2, "To Kill a Mockingbird", "Harper Lee"));
        books.add(new Book(3, "1984", "George Orwell"));
        books.add(new Book(4, "Pride and Prejudice", "Jane Austen"));
        books.add(new Book(5, "The Catcher in the Rye", "J.D. Salinger"));

        Library library = new Library(books);

        // Linear search
        System.out.println("Linear Search:");
        Book foundBook = library.linearSearchByTitle("1984");
        System.out.println(foundBook != null ? foundBook : "Book not found");

        // Sorting books for binary search
        library.sortBooksByTitle();

        // Binary search
        System.out.println("\nBinary Search:");
        foundBook = library.binarySearchByTitle("1984");
        System.out.println(foundBook != null ? foundBook : "Book not found");
    }
}
