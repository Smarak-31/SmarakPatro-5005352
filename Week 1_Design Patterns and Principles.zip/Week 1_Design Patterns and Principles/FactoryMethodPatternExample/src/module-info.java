module FactoryMethodPatternExample {
}