package factorymethodpatternexample;

public interface Document {
    void open();
}
