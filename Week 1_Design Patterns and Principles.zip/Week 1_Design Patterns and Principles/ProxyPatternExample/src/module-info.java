module ProxyPatternExample {
}