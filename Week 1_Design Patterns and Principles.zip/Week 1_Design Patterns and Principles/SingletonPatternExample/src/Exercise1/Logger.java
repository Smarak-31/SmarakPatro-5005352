package Exercise1;

public class Logger {
    // Step 2: Define a Singleton Class

    // 1. Private static instance of Logger
    private static Logger instance;

    // 2. Private constructor to prevent instantiation
    private Logger() {
        // Private constructor
    }

    // 3. Public static method to get the instance of Logger
    public static Logger getInstance() {
        if (instance == null) {
            synchronized (Logger.class) {
                if (instance == null) {
                    instance = new Logger();
                }
            }
        }
        return instance;
    }

    // Method to log messages
    public void log(String message) {
        System.out.println("Log: " + message);
    }
}
