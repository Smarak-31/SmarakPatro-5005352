module StrategyPatternExample {
}