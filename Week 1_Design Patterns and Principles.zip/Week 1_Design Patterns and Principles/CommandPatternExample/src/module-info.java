module CommandPatternExample {
}