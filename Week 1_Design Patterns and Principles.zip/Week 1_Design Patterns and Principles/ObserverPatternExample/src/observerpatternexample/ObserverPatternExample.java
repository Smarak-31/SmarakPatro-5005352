package observerpatternexample;

public class ObserverPatternExample {
    public static void main(String[] args) {
        // Create the stock market
        StockMarket stockMarket = new StockMarket();

        // Create observers
        Observer mobileApp1 = new MobileApp("MobileApp1");
        Observer mobileApp2 = new MobileApp("MobileApp2");
        Observer webApp1 = new WebApp("WebApp1");

        // Register observers
        stockMarket.registerObserver(mobileApp1);
        stockMarket.registerObserver(mobileApp2);
        stockMarket.registerObserver(webApp1);

        // Change stock price and notify observers
        stockMarket.setStockPrice(100.00);
        System.out.println("");

        // Change stock price and notify observers again
        stockMarket.setStockPrice(200.00);
        System.out.println("");

        // Deregister one observer and notify remaining observers
        stockMarket.deregisterObserver(mobileApp2);
        stockMarket.setStockPrice(300.00);
    }
}
