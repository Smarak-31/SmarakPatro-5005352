package observerpatternexample;

public interface Observer {
    void update(double stockPrice);
}
