module ObserverPatternExample {
}