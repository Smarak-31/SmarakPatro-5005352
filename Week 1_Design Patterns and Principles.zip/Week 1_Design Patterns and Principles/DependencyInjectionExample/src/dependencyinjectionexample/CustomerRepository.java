package dependencyinjectionexample;

public interface CustomerRepository {
    Customer findCustomerById(String id);
}
