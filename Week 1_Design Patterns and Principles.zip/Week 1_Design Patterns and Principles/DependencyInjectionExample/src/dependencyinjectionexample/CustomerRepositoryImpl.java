package dependencyinjectionexample;

public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(String id) {
        // For demonstration purposes, we'll return a dummy customer.
        // In a real application, this would involve querying a database or another data source.
        return new Customer(id, "John Doe", "john.doe@example.com");
    }
}
